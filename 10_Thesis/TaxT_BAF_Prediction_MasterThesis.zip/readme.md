# University of Vienna - Faculty of Computer Science Master Template Readme

This is a LaTeX class that helps writing the master's thesis within the computer science faculty of the University of Vienna.
It generates the title page and creates commands to easily adjust it.
Additionally it includes the packages needed to make a PDF-A compliance possible.
A general Layout is also provided.

## Change log:
Created 31.01.2019    Christoph Loitzenbauer
Edit 04.02.2019       Christoph Loitzenbauer      Created commands for multiple line titles and names
Edit 12.02.2019       Christoph Loitzenbauer      Updated comments
Edit 20.05.2020       Christoph Loitzenbauer      Expanded the template to support the whole thesis
Edit 27.05.2020       Christoph Loitzenbauer      Final Touches
